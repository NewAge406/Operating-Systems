

/* PCB data structure  */
struct PCB{ 
  int ID;
  int PC;
  int base;
  
  } typedef PCB;



/* Prototypes  */
void initializePCB(PCB *passedPCB);
