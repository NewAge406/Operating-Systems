#include "Job.h"

void Job::doJob(){
  int x = 0;
  processedData = jobData * 2;
  while(x < 10000){
	
	x ++;
  }
}
