#ifndef _JOB
#define _JOB
#include <stdio.h>
#include <stdlib.h>

class Job{
  public:
	void doJob();
	int jobID;
	int jobData;
	int processedData;
  private:
};
 
#endif
